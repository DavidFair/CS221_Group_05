<!-- Metadata -->
<meta charset = "utf-8" />
<meta name = "author" content = "<?php echo GROUP . ' ' . COPYRIGHT; ?>" />
<meta name = "description" content ="<?php echo APP_DESC; ?>" />
<!-- Includes -->
<link href="css/style.css" rel="stylesheet" />
<!-- Scripts -->