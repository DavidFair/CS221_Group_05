<footer>
<div class="rightNav">
    <a href="http://validator.w3.org/check?uri=referer">
        <img src="img/w3c-html.png" alt="Valid HTML5!" />
    </a>
    <a href="http://jigsaw.w3.org/css-validator/check/referer">
        <img src="img/w3c-css.png" alt="Valid CSS3!" />
    </a>
</div>
</footer>